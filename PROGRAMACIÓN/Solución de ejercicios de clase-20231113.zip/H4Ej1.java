package ud4;
//1. Que rellene un array con los 100 primeros
//números enteros y los muestre en
//pantalla en orden ascendente: 1,2..100.
public class H4Ej1 {

	public static void main(String[] args) {
		//definimos el array
		int[] nums;
		//construir: pedir RAM al SO
		nums=new int[100];
		//declaramos variables
		int numero=1;
		//rellenamos el array
		for(int i=0;i<100;i++) {
			nums[i]=numero;
			numero++;
		}
		//muestro el array
		for(int i=0;i<100;i++) {
			System.out.print(nums[i]+" ");
		}
	}

}
