package ud4;

public class H4Ej2 {
/*2. Que rellene un array con los 
 * 100 primeros números enteros 
 * y los muestre en
pantalla en orden descendente.
 * 
 * */
	public static void main(String[] args) {
		//definimos el array
		int[] nums;
		//construir: pedir RAM al SO
		nums=new int[100];
		//declaramos variables
		int numero=1;
		//rellenamos el array
		for(int i=0;i<100;i++) {
			nums[i]=numero;
			numero++;
		}

		for(int i=99;i>=0;i--) {
			System.out.print(nums[i]+" ");
		}
		

	}

}
