package ud4;

import java.util.Scanner;

/*9. Que lea 5 números por teclado, 
 * los copie a otro array multiplicados por 2 y
muestre el segundo array.
 * */
public class H2Ej9 {

	public static void main(String[] args) {
		//Declaración
		Scanner entrada=new Scanner(System.in);
		int[] nums1=new int[5];
		int[] nums2=new int[5];
		//Que lea 5 números por teclado
		for(int i=0;i<5;i++) {
			System.out.println("Introduce un un numero");
			nums1[i]=entrada.nextInt();
		}
		//los copie a otro array multiplicados por 2
		for(int i=0;i<5;i++) {
			int numAux=2*nums1[i];
			nums2[i]=numAux;
		}
		//muestre el segundo array
		for(int i=0;i<5;i++) {
			System.out.println(nums2[i]);
		}

	}

}
